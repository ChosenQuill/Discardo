public class AllSameGoal
{
	
}