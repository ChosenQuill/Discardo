public class RunGoal implements Goal
{
    public boolean hasWon(int[] hand)
    {
        int[] freqs = new int[10];
        
        for (int i = 0; i < hand.length; i++)
            freqs[hand[i]]++;
        
        int count = 0;
        int low   = 0;
        
        while (freqs[low] == 0)
            low++;
        
        for (int i = 1; i < hand.length; i++)
            if (low + i >= 10 || freqs[low + i] != 1)
                return false;

        return true;
    }
}