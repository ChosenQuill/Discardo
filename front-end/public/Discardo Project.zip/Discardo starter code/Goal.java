public interface Goal
{
    boolean hasWon(int[] hand); //public / abstract by default
}
