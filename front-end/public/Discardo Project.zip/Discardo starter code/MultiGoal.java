import java.util.*;

public class MultiGoal
{
    private List<Goal> goals;
}